package potencia_iterada;

public class Pot_ite {

    static int resultado = 1;
    static int base = 0;
    static int potencia = 0;

    public static void pot_ite(int num, int pot) {

        if (num == 0 && pot == 0) {

            System.out.println("cero elevado a la cero es una indeterminacion");

        } else {

            if (pot == 0 && num != 0) {

                resultado = 1;

            } else {

                for (int i = 0; i < pot; i++) {

                    if (i == 0) {

                        resultado = num;

                    } else {

                        resultado = resultado * num;

                    }

                }

            }

            System.out.println(resultado);

        }

    }

    public static void main(String[] args) {

        int base = 4;
        int potencia = 6;

        pot_ite(base, potencia);

    }
}
