package dividir_iteracion;

public class Div_ite {

    public static void main(String[] args) {

        int Dividendo;
        int Divisor;
        int p = 1;
        int q = 0;

        Dividendo = 4;
        Divisor = 2;

        if (Dividendo >= Divisor) {
            while ((Dividendo - Divisor) >= q) {
                q = Divisor * p;
                p++;
            }
            System.out.println("El cociente es " + (p - 1) + " y el residuo es " + ((Dividendo - q)));
        } else {
            System.out.println("El denominador debe ser menor");
        }
    }
}
