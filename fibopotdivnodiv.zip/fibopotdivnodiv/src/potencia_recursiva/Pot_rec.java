package potencia_recursiva;

public class Pot_rec {

    static int resultado = 1;
    static int base = 0;
    static int potencia = 0;

    public static int pot_rec(int num, int pot) {

        if (pot == 0 && num != 0) {

            return 1;

        } else {

            return num * pot_rec(num, pot - 1);

        }

    }

    public static void main(String[] args) {

        int base = 2;
        int potencia = 6;

        if (base == 0 && potencia == 0) {

            System.out.println("cero elevado a la cero es una indeterminacion");

        } else {

            System.out.println(pot_rec(base, potencia));

        }

    }

}
