package fibo_recursiva;

public class Fibo_rec {

    public static void main(String[] args) {

        int num = 8;

        for (int i = 0; i <= num; i++) {

            int resul = fibo_rec(i);

            if (i == num) {

                System.out.println(resul);

            }

        }
    }

    private static int fibo_rec(int num) {
        if (num == 0 || num == 1) {
            return num;
        } else {
            return fibo_rec(num - 1) + fibo_rec(num - 2);
        }
    }

}
