package dividir_recursivo;

public class Div_rec {

    private static int div_rec(int dividendo, int divisor) {

        if (divisor > dividendo) {

            return 0;

        } else {

            return 1 + div_rec(dividendo - divisor, divisor);

        }
    }

    public static void main(String[] args) {
        int dividendo;
        int divisor;

        dividendo = 4;
        divisor = 2;
        
        if (divisor > dividendo) {

            System.out.println("El denominador debe ser menor");

        } else {

            System.out.println("La división es: " + div_rec(dividendo , divisor));

        }
    }

}
