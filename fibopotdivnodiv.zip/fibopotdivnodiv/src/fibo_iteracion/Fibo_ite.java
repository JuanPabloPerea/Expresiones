package fibo_iteracion;

public class Fibo_ite {

    static int numero_ant = 1;
    static int numero_ant2 = 0;
    static int resultado = 0;
 
    public static int fibo_ite(int num) {

        if (num == 1) {

            resultado = 1;

        } else {

            for (int i = 1 ; i < num ; i++) {
                    
                resultado = numero_ant+numero_ant2; 
                
                numero_ant2 = numero_ant;
                numero_ant  = resultado;
                
            }

        }

        return resultado;
    }
 
    public static void main(String[] args) {
        
        int i=8;
        
        int resul = fibo_ite(i);
        
        System.out.println(resul);

    }

    
}
